import 'regenerator-runtime';
import 'bootstrap/dist/css/bootstrap.min.css';
import './components/navbar.js'
import './components/footer.js'
import './components/poster.js'
import './styles/main.css';
import main from "./scripts/main"

main()